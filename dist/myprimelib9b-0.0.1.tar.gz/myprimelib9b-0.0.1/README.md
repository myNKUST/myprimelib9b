# myprimelib9b
 primenumber
